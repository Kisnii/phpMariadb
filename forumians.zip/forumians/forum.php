<?php
session_start();
include "db.php"; // Database connection

$user_id = $_SESSION['user_id'] ?? null; // Get the logged-in user ID (if any)

// Check for course filter
$courseFilter = isset($_GET['course']) && $_GET['course'] !== 'all' ? $_GET['course'] : '';

// Check for search query
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build the SQL query with search and filter
$query = "SELECT posts.*, users.username FROM posts 
          JOIN users ON posts.user_id = users.id 
          WHERE 1"; // Always true, so we can append conditions easily

$params = [];
$types = '';

if ($courseFilter) {
    $query .= " AND posts.course = ?";
    $params[] = $courseFilter;
    $types .= 's';
}

if ($searchQuery) {
    $query .= " AND (posts.title LIKE ? OR posts.content LIKE ?)";
    $searchParam = "%" . $searchQuery . "%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $types .= 'ss';
}

// Prepare and execute the statement
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <style>
        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }

            .mobile-filter {
                display: block;
            }

            .post-card {
                width: 100%;
            }
        }

        @media (min-width: 769px) {
            .mobile-filter {
                display: none;
            }
        }
    </style>
</head>

<body>
    <?php include 'header.php'; ?>

    <div class="container-fluid mt-4">
        <div class="row">
            <!-- Sidebar (Filters) -->
            <div class="col-md-3 col-sm-12 mb-3">
                <h4>Filter by Course</h4>
                <ul class="list-group">
                    <li class="list-group-item"><a href="forum.php?course=all">All Courses</a></li>
                    <li class="list-group-item"><a href="forum.php?course=Computer Science">Computer Science</a></li>
                    <li class="list-group-item"><a href="forum.php?course=Psychology">Psychology</a></li>
                    <li class="list-group-item"><a href="forum.php?course=Mathematics">Mathematics</a></li>
                    <li class="list-group-item"><a href="forum.php?course=Engineering">Engineering</a></li>
                </ul>
            </div>

            <!-- Main Content (Posts) -->
            <div class="col-md-9 col-sm-12">
                <form method="GET" action="forum.php">
                    <div class="input-group mb-4">
                        <input type="text" name="search" class="form-control" placeholder="Search post here">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </form>

                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <div class="col">
                                <div class="card h-100 d-flex flex-column">
                                    <div class="card-body flex-grow-1">
                                        <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                                        <p class="card-text"><?php echo substr(htmlspecialchars($row['content']), 0, 100); ?>...</p>
                                        <p class="text-muted">By <?php echo htmlspecialchars($row['username']); ?> | <?php echo $row['created_at']; ?></p>
                                    </div>
                                    <div class="card-footer bg-white border-0">
                                        <a class="btn btn-primary" href="post.php?id=<?php echo $row['id']; ?>">Read More</a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p>No posts found.</p>
                    <?php endif; ?>
                </div>


            </div>
        </div>
    </div>


</body>

</html>