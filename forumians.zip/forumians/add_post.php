<?php
session_start();
include "db.php"; // ✅ Make sure this is correct

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION["user_id"])) { // ✅ Ensure user is logged in
        $user_id = $_SESSION["user_id"]; // Get logged-in user's ID
        $title = mysqli_real_escape_string($conn, $_POST["title"]);
        $content = mysqli_real_escape_string($conn, $_POST["content"]);
        $category = mysqli_real_escape_string($conn, $_POST["category"]);

        // ✅ Insert post into the database
        $sql = "INSERT INTO posts (user_id, title, content, category, created_at) 
                VALUES ('$user_id', '$title', '$content', '$category', NOW())";

        if ($conn->query($sql) === TRUE) {
            echo "Post added successfully!";
            header("Location: forum.php"); // Redirect to main forum page
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Error: You must be logged in to post.";
    }
}
?>



<!DOCTYPE html>
<html>

<head>
    <title>Add Post</title>
    <link rel="stylesheet" href="styles.css"> <!-- Ensure external CSS is linked -->
</head>

<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <h2>Add a New Post</h2>
        <form action="add_post.php" method="post">
            <div class="mb-3">
                <label class="form-label"><strong>Title:</strong></label>
                <input type="text" name="title" class="form-control w-50">
            </div>
            <div class="mb-3">
                <label class="form-label"><strong>Content:</strong></label>
                <textarea name="content" class="form-control w-75" rows="5"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label"><strong>Category:</strong></label>
                <select name="category" class="form-select w-50">
                    <option>Computer Science</option>
                    <option>Psychology</option>
                    <option>Mathematics</option>
                    <option>Engineering</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

    </div>
</body>

</html>