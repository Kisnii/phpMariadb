<?php
session_start();
include "db.php"; // Database connection

if (!isset($_GET['id'])) {
    die("Invalid post ID.");
}

$post_id = $_GET['id'];

// Fetch post details including the author's name
$query = "SELECT posts.*, users.username FROM posts 
          JOIN users ON posts.user_id = users.id 
          WHERE posts.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();

if (!$post) {
    die("Post not found.");
}

// Handle new comments
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $comment = trim($_POST['comment']);
    if (!empty($comment)) {
        $user_id = $_SESSION['user_id'];
        $insertComment = "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insertComment);
        $stmt->bind_param("iis", $post_id, $user_id, $comment);
        $stmt->execute();
    }
}

// Fetch comments
$commentQuery = "SELECT c.content, u.username, c.created_at 
                 FROM comments c
                 JOIN users u ON c.user_id = u.id 
                 WHERE c.post_id = ? 
                 ORDER BY c.created_at DESC";

$stmt = $conn->prepare($commentQuery);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$comments = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?></title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include 'header.php'; ?>

    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                <p class="text-muted">By <?php echo htmlspecialchars($post['username']); ?> | <?php echo $post['created_at']; ?></p>
                <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
            </div>
        </div>

        <!-- Comment Section -->
        <div class="mt-4">
            <h4>Comments</h4>
            <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST">
                    <textarea name="comment" class="form-control mb-2" rows="3" placeholder="Write a comment..." required></textarea>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </form>
            <?php else: ?>
                <p><a href="login.php">Log in</a> to comment.</p>
            <?php endif; ?>
        </div>

        <!-- Display Comments -->
        <div class="mt-3">
            <?php while ($comment = $comments->fetch_assoc()): ?>
                <div class="border p-2 mb-2">
                    <p class="mb-1"><strong><?php echo htmlspecialchars($comment['username']); ?></strong></p>
                    <p class="mb-1"><?php echo htmlspecialchars($comment['content']); ?></p>
                    <small class="text-muted"><?php echo $comment['created_at']; ?></small>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

</body>

</html>